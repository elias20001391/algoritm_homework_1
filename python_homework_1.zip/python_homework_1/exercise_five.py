



mogodi = 20000000

bardasht = float(input("how much:"))

if bardasht >= 0 :
    if bardasht <= mogodi:
        mogodi -= bardasht
        print("ok")
        print(mogodi)
        if mogodi < 100000:
            print("the entity is running out your enyiyt:",mogodi,"toman")
    else:
        print("your mogodi is not enough")
else:
    print("bardashtet baiad balay 0 toman bashe ")