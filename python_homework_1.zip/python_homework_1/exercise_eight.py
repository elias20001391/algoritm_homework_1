




age = float(input("enter your age:"))
day = input("enter a day you want:")
price = 200000

if age < 12:
    price = (price / 100) * 50
    print("you shoud pay:",price)
elif age >= 60:
    price = (price / 100) * 30
    print("you shoud pay:",price)
elif day == "tuesday":
    price = (price / 100) * 20
    print("you shoud pay:",price)
else:
    print("you shoud pay:",price)