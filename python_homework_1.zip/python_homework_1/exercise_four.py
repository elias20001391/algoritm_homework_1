




dama = float(input("dama ro vared konid:"))
rain = input("rain?:")

if dama <= 0 :
    print("lebas zakhim beposhid")
elif dama <= 10 :
    print("lebas garm beposhid")
elif dama <= 25 :
    print("hava moteaadel ast")
else:
    print("lebas khonak beposhid")

if rain == "yes":
    print("chatr bar darid")
