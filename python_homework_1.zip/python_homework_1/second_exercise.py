





masafat = float(input("masafat ro vared konid:"))
hazine = (masafat * 8000) + 30000

if masafat > 20:
    hazine = (hazine / 100) * 95
    print("hazine safar:",round(hazine),"toman")
else:
    print("hazine safar:",round(hazine),"toman")