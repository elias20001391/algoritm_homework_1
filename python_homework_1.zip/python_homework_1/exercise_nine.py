




food = input("what are you want:")
number = float(input("how many:"))


if number >= 1:
    if food == "pizza":
        price = 250000 * number
        if price > 500000:
            print("you have one free cola , you shoud pay:",price)
        else:
            print("you shoud pay:",price)
    elif food == "burger":
            price = 180000 * number
            if price > 500000:
                print("you have one free cola , you shoud pay:",price)
            else:
                print("you shoud pay:",price)
    elif food == "sandwich":
            price = 120000 * number
            if price > 500000:
                print("you have one free cola , you shoud pay:",price)
            else:
                print("you shoud pay:",price)
    else:
         print("this food not in meno")
else:
     print("you shoud enter postive number:")