



masraf = float(input("masrafeton ro vard konid:"))
hazine = 0


if masraf <= 100:
    hazine = masraf * 1000
    print("hazine:",hazine,"toman")
elif masraf <= 200:
    hazine = masraf * 1500
    print("hazine:",hazine,"toman")
else:
    hazine = masraf * 2500
    print("hazine:",hazine,"toman")