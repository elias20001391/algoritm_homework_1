



ersal = input("chose your ersal normal or fast:")

hazine = float(input("enter your hazine:"))

if ersal == "normal":
    if hazine > 2000000:
        print("your ersal is free you shoud pay:",hazine)
    else:
        print("hazine:", hazine + 50000 , "toman")
elif ersal == "fast":
    print("you shoud pay:", hazine + 100000)
else:
    print("your ersal chose is wrong")