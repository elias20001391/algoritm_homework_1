




age = int(input("enter your age:"))

if age < 18:
    print("you are young")
else:
    username = input("enter your username:")
    password = input("enter your password:")

    if password == "king arthur 7300" and username == "dark shadow":
        print("login completed")
    else:
        if password != "king arthur 7300" and username != "dark shadow":
            print("your username and password is wrong")
        elif password != "king arthur 7300" and username == "dark shadow":
            print("your password is wrong")
        else:
            print("your username is wrong")