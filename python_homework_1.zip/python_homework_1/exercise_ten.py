







mogodi = 20000000

password = float(input("enter your password:"))
bardasht = float(input("how many you want bardasht(baiad mazrab 50000 toman bashad):"))


if password == 4321:
    if bardasht % 50000 == 0:
        if bardasht <= mogodi:
            mogodi -= bardasht
            print("ok,your new mogodi:",mogodi,"toman")
        else:
            print("mogodi cafi nist")
    else:
        print("mazrab 50000 nist")
else:
    print("wrong password")